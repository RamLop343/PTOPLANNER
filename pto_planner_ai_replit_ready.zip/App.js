
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import ScheduleSelection from './screens/ScheduleSelection';
import EnterDetails from './screens/EnterDetails';
import CalendarPlanner from './screens/CalendarPlanner';
import HomeScreen from './screens/HomeScreen';
import LoginScreen from './screens/LoginScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="LoginScreen" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="LoginScreen" component={LoginScreen} />
        <Stack.Screen name="ScheduleSelection" component={ScheduleSelection} />
        <Stack.Screen name="EnterDetails" component={EnterDetails} />
        <Stack.Screen name="CalendarPlanner" component={CalendarPlanner} />
        <Stack.Screen name="HomeScreen" component={HomeScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
