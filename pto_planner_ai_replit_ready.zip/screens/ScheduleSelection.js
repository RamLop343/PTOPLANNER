
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function ScheduleSelection({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Select Your Work Schedule</Text>
      {['Regular 9–5', 'Rotating (custom shift pattern)', 'Other (manually entered)'].map(option => (
        <TouchableOpacity key={option} style={styles.button} onPress={() => navigation.navigate('EnterDetails')}>
          <Text>{option}</Text>
        </TouchableOpacity>
      ))}
      <TouchableOpacity style={styles.continue} onPress={() => navigation.navigate('EnterDetails')}>
        <Text style={styles.continueText}>Continue</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center', backgroundColor: '#fff' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  button: { padding: 15, marginVertical: 10, borderWidth: 1, borderColor: '#295f48', borderRadius: 6 },
  continue: { marginTop: 30, backgroundColor: '#295f48', padding: 15, borderRadius: 6, alignItems: 'center' },
  continueText: { color: '#fff', fontWeight: 'bold' },
});
