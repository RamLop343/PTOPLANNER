
import React, { useState } from 'react';
import { View, Text, TextInput, Switch, StyleSheet, TouchableOpacity } from 'react-native';

export default function EnterDetails({ navigation }) {
  const [holidayToggle, setHolidayToggle] = useState(true);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter Details</Text>
      <TextInput style={styles.input} placeholder="Date started current cycle (e.g. 3/5/2024)" />
      <TextInput style={styles.input} placeholder="PTO accrual rate (e.g. 4 hours/month)" />
      <TextInput style={styles.input} placeholder="Current PTO balance (e.g. 10 days)" />
      <View style={styles.toggleRow}>
        <Text>U.S. Holidays</Text>
        <Switch value={holidayToggle} onValueChange={setHolidayToggle} />
      </View>
      <TouchableOpacity style={styles.nextButton} onPress={() => navigation.navigate('CalendarPlanner')}>
        <Text style={styles.continueText}>Next</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  input: { borderBottomWidth: 1, padding: 10, marginVertical: 10 },
  toggleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 20 },
  nextButton: { marginTop: 30, backgroundColor: '#295f48', padding: 15, borderRadius: 6, alignItems: 'center' },
  continueText: { color: '#fff', fontWeight: 'bold' },
});
